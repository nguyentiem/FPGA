Note: The 'MAKEXCOE.EXE' executable file was compiled for operation under MS DOS.

