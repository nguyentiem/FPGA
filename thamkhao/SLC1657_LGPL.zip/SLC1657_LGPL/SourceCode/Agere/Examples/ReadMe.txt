Notice:
-------

The examples that normally reside in this directory have been removed because they use RAM and ROM elements created by the manufacturers' core generation tools.  The output from those tools bear copyrights that prevent us from sharing them.  However, you can recreate all of the examples by following the directions in the SLC1657 Technical Reference Manual.  We apologize for any inconvienience.

We will include these files in the future if we can obtain permission to use them from the manufacturer.

- WD Peterson 9 Sep 2003


