Note: The 'MAKAMIF.EXE' executable file was compiled for operation under MS DOS.

