/********************************************************************/
/* License:     CALCDEMO.C                                          */
/*              Copyright (C) 2003 Silicore Corporation             */
/*                                                                  */
/*              This library is free software; you can              */
/*              redistribute it and/or modify it under the terms    */
/*              of the GNU Lesser General Public License version    */
/*              2.1 as published by the Free Software Foundation.   */
/*                                                                  */
/*              This library is distributed in the hope that it     */
/*              will be useful, but WITHOUT ANY WARRANTY; without   */
/*              even the implied warranty of MERCHANTABILITY or     */
/*              FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      */
/*              Lesser General Public License for more details.     */
/*                                                                  */
/*              You should have received a copy of the GNU Lesser   */
/*              General Public License along with this library;     */
/*              if not, write to the Free Software Foundation,      */
/*              Inc., 59 Temple Place, Suite 330, Boston, MA        */
/*              02111-1307  USA                                     */
/*                                                                  */
/* Support:     Support for this software in the form of            */
/*              maintenance, system integration, consulting and     */
/*              training is available for a fee from Silicore       */
/*              Corporation.  For more information please refer     */
/*              to the Silicore web site at: www.silicore.net.      */
/*                                                                  */
/********************************************************************/

/********************************************************************/
/*                                                                  */
/*                       - Module History-                          */
/*                                                                  */
/*            Description                    Name / Date            */
/*  -----------------------------   ------------------------------  */
/*  Initial design complete:          WD Peterson / 24 MAY 2001     */
/*  Release under the LGPL:           WD Peterson / 03 SEP 2003     */
/*                                                                  */
/********************************************************************/

/********************************************************************/
/*                       Compiler Information                       */
/*                                                                  */
/* This software is intended to be compiled on the 'CC5X C Compiler */
/* for PIC(R) devices from B Knudsen Data (Trondheim, Norway).  For */
/* more information please see the website at: www.bknd.com         */
/********************************************************************/

/********************************************************************/
/*            Identify the Microprocessor Architecture              */
/********************************************************************/

#include "16c57.h"                  /* 'CC5X header for the SLC1657 */


/********************************************************************/
/*                       Configuration Bits                         */
/*                                                                  */
/* The following configuration bits are required when operating     */
/* this software on a PIC16C57 processor.  They are not required    */
/* when this code is operating on a SLC1657 processor.  However,    */
/* they are included here because this code is used as part of a    */
/* conformance test that verifies code compatibility between the    */
/* two processors.                                                  */
/*                                                                  */
/* These configuration bits (on the PIC16C57) are used to: (a) turn */
/* the watchdog timer off at initialization, (b) set up the crystal */
/* oscillator for external excitation and (c) turn off the code     */
/* protection function.                                             */
/********************************************************************/

#pragma config WDTE=off             /* CNFG: Watchdog off           */
#pragma config FOSC=XT              /* CNFG: Crystal oscillator     */
#pragma config |= 0x008             /* CNFG: Code protection off    */


/********************************************************************/
/*                        Math Libraries                            */
/*                                                                  */
/* All floating point math libraries are located in code bank 3.    */
/* The local variables used for these libraries are located in RAM  */
/* bank 3.                                                          */
/********************************************************************/

#pragma     codepage 3
#pragma     rambank  3

#define     FP_OPTIM_SIZE       /* Optimize floating point for size */
#include    "math24f.h"         /* 24-bit floating point math lib   */

/********************************************************************/
/*                      Function Prototypes                         */
/********************************************************************/

void            AsciiToFloat( void );
void            ClearDisplay( void );
void            FloatToAscii( void );
unsigned char   LCD_Operation( char, unsigned char );
void            main( void );
void            MathFunc_Add( void );
void            MathFunc_Div( void );
void            MathFunc_Mul( void );
void            MathFunc_Sub( void );
char            ScanKey( void );
void            ShiftDispLeft( char );
void            ShiftDispRight( char );


/********************************************************************/
/*                       Global Variables                           */
/********************************************************************/

bank0   char    disp[8];            /* ASCII characters on LCD      */
bank0   char    disp_buf;           /* LCD display buffer           */
shrBank float   working;            /* Calc: working register       */
shrBank float   lastent;            /* Calc: last entry reg.        */

#pragma codepage 0
#pragma rambank  0


/********************************************************************/
/*                                                                  */
/* Function:    main()                                              */
/*                                                                  */
/* Description: Entry point after a hardware reset.                 */
/*                                                                  */
/********************************************************************/

void main( void )
{
bit             dp_flag;                /* Decimal point flag       */
bit             neg_flag;               /* Negative number flag     */
unsigned char   numdigs;                /* LCD: numerical digits    */
unsigned char   totdigs;                /* LCD: total digits        */
char            m,n;                    /* General purpose          */
char            newchar;
unsigned char   funcpend;               /* Function pending         */
bit             num_flag;


    /****************************************************************/
    /* Reboot location.  Software resets jump here.                 */
    /****************************************************************/

reboot:


    /****************************************************************/
    /* Initialize general purpose variables.                        */
    /****************************************************************/

    lastent = 0.0;
    working = 0.0;


    /****************************************************************/
    /* Initialize the I/O ports.                                    */
    /****************************************************************/

    TRISA = 0xFF;                   /* PORTA: inputs                */
    TRISB = 0x00;                   /* PORTB: outputs               */
    TRISC = 0xFF;                   /* PORTC: inputs (temporary)    */

    PORTA = 0x00;                   /* Preset the output values     */
    PORTB = 0x00;
    PORTC = 0x00;


    /****************************************************************/
    /* Enable floating point rounding.                              */
    /****************************************************************/

    InitFpFlags();


    /****************************************************************/
    /* Initialize the function flags.                               */
    /****************************************************************/

    funcpend     = 0x00;
    num_flag     = 0;


    /****************************************************************/
    /* Initialize the timer for use by delay functions.  Once       */
    /* initialized, a delay period can be created by clearing       */
    /* the TMR0 register, and then monitoring the same register     */
    /* until the right number of clock ticks pass.  The software    */
    /* in this file assumes that the external timer input is        */
    /* connected to a 1 KHz clock.                                  */
    /****************************************************************/

    clrwdt();                       /* Clear the watchdog timer     */
    TMR0 = 0x00;                    /* Clear the TMR0 counter       */
    OPTION = 0x02;                  /* Set prescaler                */
    clrwdt();                       /* Clear the watchdog timer     */
    OPTION = 0x28;                  /* Set clock source             */


    /****************************************************************/
    /* Initialize the Optrex DMC-16117A LCD display.  Also initial- */
    /* ize the various variables associated with the LCD display.   */
    /* The initial 200 millisecond delay is is required to make     */
    /* sure that the LCD powers up at the same time that the micro- */
    /* processor does.                                              */
    /****************************************************************/

    TMR0 = 0x00;                    /* Delay for 100 milliseconds   */
    do {} while( TMR0 < 100 );

    LCD_Operation( 'C', 0x38 );     /* 8-bit, 5x7 mode              */
    LCD_Operation( 'C', 0x0c );     /* Display on, cursor off       */
    LCD_Operation( 'C', 0x06 );     /* Increment mode & shift disp. */

    ClearDisplay();                 /* Clear the display (show '0') */

    totdigs      = 1;
    numdigs      = 0;
    dp_flag      = 0;
    neg_flag     = 0;


    /****************************************************************/
    /* Operate the calculator.                                      */
    /****************************************************************/

    while( 1 )
    {
        /************************************************************/
        /* Wait here until a key is pressed.  When pressed, get the */
        /* key name.                                                */
        /************************************************************/

        do{ newchar = ScanKey(); } while( newchar == 0x00 );

        if( (newchar >= 0x30) && (newchar <= 0x39) ) { num_flag = 1; }


        /************************************************************/
        /* If the entry is a number, and any of the functions       */
        /* (+,-,* or /) are pending, then convert the current value */
        /* in the display to a floating point number and clear the  */
        /* display.                                                 */
        /************************************************************/

        if( (num_flag || (newchar == '.')) && funcpend.7 )
        {
            AsciiToFloat();
            lastent = working;
            ClearDisplay();
            totdigs      = 1;
            numdigs      = 0;
            dp_flag      = 0;
            neg_flag     = 0;

            funcpend.7   = 0;
        }


        /************************************************************/
        /* If the 'CLR' key was pushed, then restart.               */
        /************************************************************/

        if( newchar == 'C' ) { goto reboot; }


        /************************************************************/
        /* If a number key was pushed, then enter the number (under */
        /* certain restrictions).                                   */
        /************************************************************/

        else if( num_flag )
        {
            if( (numdigs == 0) && (newchar == '0') && (dp_flag == 0) )
            {
            }
            else if( numdigs == 0 )
            {
                ShiftDispLeft( newchar );
                numdigs = 1;

                if( dp_flag == 0 )
                {
                    totdigs = 1;
                    LCD_Operation( 'C', 0xc8 );     /* Reset LCD address    */
                }
                else
                {
                    totdigs++;
                    LCD_Operation( 'C', 0x18 );     /* Shift left           */
                }

                LCD_Operation( 'D', newchar );      /* Add new character    */

            }
            else if( numdigs < 5 )
            {
                ShiftDispLeft( newchar );
                totdigs++;
                numdigs++;
                LCD_Operation( 'D', newchar );  /* Add new character    */
                LCD_Operation( 'C', 0x18 );     /* Shift left           */
            }
            else
            {
            }

            num_flag = 0;
        }


        /************************************************************/
        /* If the decimal point was pushed, then record the event   */
        /* but do not display it yet.  The decimal point only gets  */
        /* displayed after a number key is pressed.                 */
        /************************************************************/

        else if( (newchar == '.') && (numdigs < 5) && (dp_flag == 0) )
        {
            ShiftDispLeft( '.' );
            totdigs++;
            LCD_Operation( 'D', newchar );  /* Add new character    */
            LCD_Operation( 'C', 0x18 );     /* Shift left           */

            dp_flag = 1;
        }


        /************************************************************/
        /* If the '+/-' key was pushed, then put that in front of   */
        /* all the numbers (under certain restrictions).  Also note */
        /* that the symbol can be toggled.                          */
        /************************************************************/

        else if( (newchar == '@') && (numdigs != 0) )
        {
            /********************************************************/
            /* Add or subtract the '-' character.                   */
            /********************************************************/

            if( neg_flag == 0 )
            {
                n = 7 - totdigs;
                disp[n] = '-';
                totdigs++;
                neg_flag = 1;
            }
            else
            {
                totdigs--;
                n = 7 - totdigs;                
                disp[n] = ' ';
                neg_flag = 0;
            }


            /********************************************************/
            /* Update the entire display.                           */
            /********************************************************/

            LCD_Operation( 'C', 0x01 );     /* Clear the display    */
            LCD_Operation( 'C', 0xc8 );     /* Init address pointer */

            for( m = 0; m < totdigs; m++ )
            {
                n = 8 - totdigs;
                n = n + m;
                n = disp[n];
                LCD_Operation( 'D', n );    /* Add new character    */
                LCD_Operation( 'C', 0x18 ); /* Shift left           */
            } 
        }


        /************************************************************/
        /* Add key.                                                 */
        /************************************************************/

        else if( newchar == '+' )
        {
            if( funcpend != 0x00 ){ goto equal_key; }

            funcpend = 0x81;
        }


        /************************************************************/
        /* Subtract key.                                            */
        /************************************************************/

        else if( newchar == '-' )
        {
            if( funcpend != 0x00 ){ goto equal_key; }
            funcpend = 0x82;
        }


        /************************************************************/
        /* Multiply key.                                            */
        /************************************************************/

        else if( newchar == 'X' )
        {
            if( funcpend != 0x00 ){ goto equal_key; }

            funcpend = 0x84;
        }


        /************************************************************/
        /* Div key.                                                 */
        /************************************************************/

        else if( newchar == '/' )
        {
            if( funcpend != 0x00 ){ goto equal_key; }

            funcpend = 0x88;
        }


        /************************************************************/
        /* Equal key.                                               */
        /************************************************************/

        else if( (newchar == '=') && (funcpend != 0x00) )
        {
            equal_key:

            AsciiToFloat();

            InitFpFlags();

                 if( funcpend.0 ) { MathFunc_Add(); }
            else if( funcpend.1 ) { MathFunc_Sub(); }
            else if( funcpend.2 ) { MathFunc_Mul(); }
            else if( funcpend.3 ) { MathFunc_Div(); }

            if( (FpFlags & 0x2e) != 0x00 ) { goto FpError; }

            FloatToAscii();

            if( working == 65535 ) { goto FpError; }

                 if( newchar == '+' ) { funcpend = 0x81; }
            else if( newchar == '-' ) { funcpend = 0x82; }
            else if( newchar == 'X' ) { funcpend = 0x84; }
            else if( newchar == '/' ) { funcpend = 0x88; }
            else                      { funcpend = 0x00; }

            numdigs = 5;

            goto endofsection;

            FpError:

    disp[0] = 'F';
    disp[1] = 'P';
    disp[2] = ' ';
    disp[3] = 'E';
    disp[4] = 'R';
    disp[5] = 'R';
    disp[6] = 'O';
    disp[7] = 'R';

    LCD_Operation( 'C', 0x01 );     /* Clear the display            */
    LCD_Operation( 'C', 0xc8 );     /* Initialize address pointer   */

    for( n = 0; n < 8; n++ )
    {
        disp_buf = disp[n];
        LCD_Operation( 'D', disp_buf ); /* Display number           */
        LCD_Operation( 'C', 0x18     ); /* Shift the display left   */
    }
            
        while( ScanKey() != 'C' ) {}
        goto reboot;


 endofsection:

        }


        /************************************************************/
        /* Otherwise, ignore the key.                               */
        /************************************************************/

        else
        {
        }
    }
}


#pragma     codepage 1
#pragma     rambank  1

/********************************************************************/
/*                                                                  */
/* Function:    ClearDisplay()                                      */
/*                                                                  */
/* Description: Resets the LCD display, clears the 'disp[]' array   */
/*              and puts a zero on the display.                     */
/*                                                                  */
/********************************************************************/

void ClearDisplay( void )
{
int n;

    LCD_Operation( 'C', 0x01 );     /* Clear the display            */
    LCD_Operation( 'C', 0xc8 );     /* Initialize address pointer   */

    LCD_Operation( 'D', '0' );      /* Display '0'                  */
    LCD_Operation( 'C', 0x18 );     /* Shift the display left       */

    for( n = 0; n < 8; n++ ) { disp[n] = ' '; }

    disp[0]      = '0';
}


/********************************************************************/
/*                                                                  */
/* Function:    LCD_Operation()                                     */
/*                                                                  */
/* Description: Performs the indicated operation on the LCD.  Note  */
/*              that the same routine is used to read LCD data,     */
/*              read LCD address, send LCD data and send LCD        */
/*              LCD command.  The type of operation is indicated    */
/*              thusly:                                             */
/*                                                                  */
/*                Operation       Type Character                    */
/*              --------------    --------------                    */
/*              READ LCD DATA:         'R'                          */
/*              READ LCD ADDR:         'A'                          */
/*              SEND LCD DATA:         'D'                          */
/*              SEND LCD CMND:         'C'                          */
/*                                                                  */
/********************************************************************/

unsigned char LCD_Operation( char type, unsigned char command )
{
unsigned char   input_data;

    /****************************************************************/
    /* Parse the operation type.  Most of the code in this routine  */
    /* is the same, except for some of the handshaking lines.  The  */
    /* switch statement sets the handshaking lines depending upon   */
    /* the operation.                                               */
    /****************************************************************/

    switch( type )
    {
        case 'R':
            PORTB.6 = 1;            /* Assert RS line.              */
            PORTB.6 = 1;           
        case 'A':
            PORTB.7 = 1;            /* Assert RW line.              */
            break;
        case 'D':
            PORTB.6 = 1;            /* Assert RS line.              */
            PORTB.6 = 1;
        case 'C':
            PORTC = command;        /* Send out command.            */
            TRISC = 0x00;
            break;
        default:
            break;
    }


    /****************************************************************/
    /* Complete the common part(s) of the operation.                */
    /****************************************************************/

    PORTB.5 = 1;                    /* Assert 'E' line.             */
    PORTB.5 = 1;

    input_data = PORTC;             /* Read input data (if used).   */

    PORTB.5 = 0;                    /* Negate 'E' line.             */
    PORTB.5 = 0;
    PORTB.6 = 0;                    /* Negate 'RS' line.            */
    PORTB.6 = 0;
    PORTB.7 = 0;                    /* Negate 'RW' line.            */
    PORTB.7 = 0;


    /****************************************************************/
    /* Delay 2-3 milliseconds.  This gives the LCD enough time to   */
    /* process the command before attempting another one.           */
    /****************************************************************/

    TMR0 = 0x00;
    do {} while( TMR0 < 3 );


    /****************************************************************/
    /* All done, so return with the input data.                     */
    /****************************************************************/

    return( input_data );
}

/********************************************************************/
/* Function:    ScanKey()                                           */
/*                                                                  */
/* Description: Scans the keyboard.  If there aren't any keys       */
/*              pressed, then the function returns the NULL         */
/*              character (0x00).  If a key has been pushed, then   */
/*              it returns the ASCII value of the pushed key.       */
/*              The function also debounces the keyboard.           */
/*                                                                  */
/*              Since the keyboard has non-ASCII characters on it,  */
/*              there are few exceptions to the return value.  The  */
/*              following ASCII values are returned thusly:         */
/*                                                                  */
/*              KEY: +/-, return '@'                                */
/*              KEY:  F1, return '$'                                */
/*              KEY:  F2, return '&'                                */
/*              KEY: CLR, return 'C'                                */
/*                                                                  */
/*              The keyboard is scanned by placing a binary value   */
/*              on PORTB, which corresponds to a row number between */
/*              zero and four.  For example, when the first row is  */
/*              scanned, then a binary value 11110 is placed onto   */
/*              PORTB.  When the second row is scanned, a binary    */
/*              value of 11101 is placed onto the port and so       */
/*              forth.                                              */
/*                                                                  */
/*              At the same time, the keyboard columns are          */
/*              monitored by reading PORTA.  If none of the keys    */
/*              are pressed, then PORTA will always read as zero,   */
/*              regardless of the excitation to the keyboard.       */
/*              However, if a key is pressed, then the key number   */
/*              can be determined by knowning the keyboard excita-  */
/*              tion and response.                                  */
/*                                                                  */
/********************************************************************/

char ScanKey( void )
{
unsigned char   col;
unsigned char   colex;
char            key;
unsigned char   keynum;
static   char   lastkey;
unsigned char   row;
unsigned char   rowex;


    /****************************************************************/
    /* Initialize variables.                                        */
    /****************************************************************/

    keynum = 0x00;
    rowex  = 0x1e;


    /****************************************************************/
    /* Generate an excitation to each of the five keyboard rows.    */
    /****************************************************************/

    for( row = 0; row < 5; row++ )
    {
        /************************************************************/
        /* Place an excitation value onto the keyboard row.         */
        /************************************************************/

        PORTB = rowex;


        /************************************************************/
        /* Delay for at least a millisecond.  This does two things: */
        /* (1) it gives plenty of time for the excitation signal    */
        /* to overcome the capacitance of the key switches and (2)  */
        /* it serves as a keyboard debounce routine.                */
        /************************************************************/

        TMR0 = 0x00;
        do {} while( TMR0 < 2 );


        /************************************************************/
        /* Read back the value generated by the keyboard.  If none  */
        /* of the keys are pressed, then the keyboard will return   */
        /* zero.  If one or more of the keys are pressed, then the  */
        /* keyboard will return a non-zero value.                   */
        /************************************************************/

        colex = 0x08;

        for( col = 0; col < 4; col++ )
        {
            /********************************************************/
            /* If a key has been pressed, then determine which one. */
            /********************************************************/

            if( (PORTA & colex) == 0x00 )
            {
                switch( keynum )
                {
                    case  0: key = '0'; break;
                    case  1: key = '.'; break;
                    case  2: key = '@'; break;
                    case  3: key = '='; break;
                    case  4: key = '1'; break;
                    case  5: key = '2'; break;
                    case  6: key = '3'; break;
                    case  7: key = '+'; break;
                    case  8: key = '4'; break;
                    case  9: key = '5'; break;
                    case 10: key = '6'; break;
                    case 11: key = '-'; break;
                    case 12: key = '7'; break;
                    case 13: key = '8'; break;
                    case 14: key = '9'; break;
                    case 15: key = 'X'; break;
                    case 16: key = '$'; break;
                    case 17: key = '&'; break;
                    case 18: key = 'C'; break;
                    case 19: key = '/'; break;
                    default:   key = 0x00;
                }


                /****************************************************/
                /* If the same key is pressed (that was pressed     */
                /* last time through the routine), then we'll       */
                /* assume that the user is just pushing the key for */
                /* a long time, and ignore the new value.           */
                /****************************************************/

                if( lastkey == key ) { return( 0x00 ); }


                /****************************************************/
                /* A new key has been pushed, so return the value.  */
                /****************************************************/

                lastkey = key;
                return( key );
            }

            /********************************************************/
            /* No key was pressed, so go to the next column.        */
            /********************************************************/

            colex = colex >> 1;
            keynum++;
        }

        /************************************************************/
        /* Determine the next excitation value.                     */
        /************************************************************/

        rowex = ((rowex << 1) | 0x01) & 0x1f;
    }

    /****************************************************************/
    /* All keys are released, so return with the NULL character.    */
    /****************************************************************/

    lastkey = 0x00;
    return( 0x00 );
}


/********************************************************************/
/*																	*/
/* Function:    AsciiToFloat()                                      */
/*                                                                  */
/* Description: Converts the ASCII value in the 'disp[]' array      */
/*              to a floating point value in the 'working'          */
/*              register.                                           */
/*                                                                  */
/********************************************************************/

void AsciiToFloat( void )
{
int     expo;
int     n;
bit     neg;
uns16   dval;
uns16   uval;
uns16   pwr;
float   temp;


	/****************************************************************/
    /* Find out if the number is negative, and locate the decimal   */
    /* point.                                                       */
	/****************************************************************/

    neg     = 0;
    expo    = 0;

    for( n = 0; n < 8; n++ )
    {
        if( disp[n] == '-' ) { neg = 1; }
        if( disp[n] == '.' ) { expo = 7 - n; }
    }


	/****************************************************************/
    /* Convert into an unsigned integer.  The position of the       */
    /* decimal point has already been found, so ignore the decimal  */
    /* point for now.                                               */
	/****************************************************************/

    uval = 0;
    pwr  = 1;

    for( n = 7; n >= 2; n-- )
    {
        disp_buf = disp[n];

        if( disp_buf >= 0x30 )
        {
            disp_buf = disp_buf - 0x30;
            dval     = (uns16) disp_buf;
            dval     = dval * pwr;
            uval     = uval + dval;

            pwr      = pwr * 10;
        }
    }


	/****************************************************************/
    /* Convert the unsigned integer into a floating point value     */
    /* and adjust the decimal point.                                */
	/****************************************************************/

    temp = lastent;

    working = uval;

    lastent = 0.1;

    for( n = 0; n < expo; n++ ) { MathFunc_Mul(); }

    lastent = temp;

    if( neg == 1 ){ working.15 = 1; }

}


/********************************************************************/
/*																	*/
/* Function:    ShiftDispRight()                                    */
/*                                                                  */
/* Description: Shifts the ASCII display buffer to the right by     */
/*              one character.  The left-hand character is filled   */
/*              with the ASCII character that is passed to the      */
/*              routine.                                            */
/*                                                                  */
/********************************************************************/

void ShiftDispRight( char endchar )
{
    disp[7] = disp[6];
    disp[6] = disp[5];
    disp[5] = disp[4];
    disp[4] = disp[3];
    disp[3] = disp[2];
    disp[2] = disp[1];
    disp[1] = disp[0];
    disp[0] = endchar;
}


/********************************************************************/
/*																	*/
/* Function:    ShiftDispLeft()                                     */
/*                                                                  */
/* Description: Shifts the ASCII display buffer to the left by      */
/*              one character.  The right-hand character is filled  */
/*              with the ASCII character that is passed to the      */
/*              routine.                                            */
/*                                                                  */
/********************************************************************/

void ShiftDispLeft( char endchar )
{
    disp[0] = disp[1];
    disp[1] = disp[2];
    disp[2] = disp[3];
    disp[3] = disp[4];
    disp[4] = disp[5];
    disp[5] = disp[6];
    disp[6] = disp[7];
    disp[7] = endchar;
}

void MathFunc_Mul( void ) { working = lastent * working; }
void MathFunc_Sub( void ) { working = lastent - working; }

#pragma     codepage 2
#pragma     rambank  2

/********************************************************************/
/*                                                                  */
/* Function:    FloatToAscii()                                      */
/*                                                                  */
/* Description: Converts the floating point value in the 'working'  */
/*              register to an 8-digit ASCII string in the 'disp[]' */
/*              array.  The contents of the 'working' register is   */
/*              not touched.  The contents of the 'lastent'         */
/*              register is corrupted.                              */
/*                                                                  */
/*              The routine will correctly convert numbers between  */
/*              +/- 65535 downto +/- 0.00001.                       */
/*                                                                  */
/********************************************************************/

void FloatToAscii( void )
{
int     cnt;
int     expo;
uns16   icv;
uns16   icx;
int     n;
bit     dp_flag;
bit     neg_flag;
float   temp;


	/****************************************************************/
    /* Initialize variables.  Clear the display buffer, clear the   */
    /* negative bit and temporarily save the floating point value.  */
	/****************************************************************/

    for( n = 0; n < 8; n++ ) { disp[n] = '0'; }

    neg_flag = 0;
    if( working.15 == 1 ) { working.15 = 0; neg_flag = 1; }

    temp = working;


	/****************************************************************/
    /* Multiply the input value by the maximum multiplier.  This    */
    /* establishes the maximum number of digits that will be        */
    /* displayed.                                                   */
	/****************************************************************/

    lastent = 10.0;
    expo = 0;

    while( working < 6553 )
    {
        MathFunc_Mul();
        expo++;
    }

    lastent = 10.0;
    working =  temp;

    for( n = 0; n < expo; n++ ){ MathFunc_Mul(); }


	/****************************************************************/
    /* Convert the number into a 16-bit unsigned integer.           */
	/****************************************************************/

    icv = working;


	/****************************************************************/
    /* Convert the integer into decimal, ASCII characters.          */
	/****************************************************************/

    for( n = 2; n < 7; n++ )
    {
        switch( n )
        {
            case 2:  icx = 10000; break;
            case 3:  icx = 1000;  break;
            case 4:  icx = 100;   break;
            case 5:  icx = 10;    break;
            default: icx = 1;     break;
        }
        cnt = icv / icx;
        disp_buf = cnt + 0x30;
        disp[n] = disp_buf;
        icx = icx * cnt;
        icv = icv - icx;
    }


	/****************************************************************/
    /* Add the decimal point to the display.  The position of the   */
    /* decimal point was found above, and is stored in 'expo'.      */
	/****************************************************************/

    while( expo > 5 ) { expo--; ShiftDispRight( '0' ); }

    disp[7] = '.';

    for( n = 0; n < expo; n++ )
    {
        cnt = 6 - n;
        disp_buf = disp[cnt];
        disp[cnt] = '.';
        cnt = 7 - n;
        disp[cnt] = disp_buf;
    }


	/****************************************************************/
    /* Remove the leading and trailing zeros.                       */
	/****************************************************************/

    while( (disp[0] == 0x30) || (disp[0] == ' ') ) { ShiftDispLeft( ' ' ); }
    while( (disp[7] == 0x30) || (disp[7] == ' ') ){ ShiftDispRight(' '); }
    if( disp[7] == '.' ) { ShiftDispRight(' '); }

    dp_flag = 0;
    for( n = 0; n < 8; n++ )
    {
        if( disp[n] == '.' )
        {
            dp_flag = 1;
            if( disp[n-1] == ' ') { disp[n-1] = '0'; }
        }
    }

    n = 0;
    while( (disp[n] <= 0x30) && (n < 8) )
    {
        if( dp_flag == 0 ) { disp[n] = ' '; }
        if( disp[n] == ' ' ) { cnt = n; }
        n++;
    }

    if( neg_flag == 1 ) { disp[cnt] = '-'; }

    working = temp;


	/****************************************************************/
    /* Display the result.                                          */
	/****************************************************************/

    LCD_Operation( 'C', 0x01 );     /* Clear the display            */
    LCD_Operation( 'C', 0xc8 );     /* Initialize address pointer   */

    for( n = 0; n < 8; n++ )
    {
        disp_buf = disp[n];
        LCD_Operation( 'D', disp_buf ); /* Display number           */
        LCD_Operation( 'C', 0x18     ); /* Shift the display left   */
    }
}

#pragma     codepage 3
#pragma     rambank  3

void MathFunc_Add( void ) { working = lastent + working; }
void MathFunc_Div( void ) { working = lastent / working; }
