/****************************************************************************/
/*                      - SLC1657 DOWNLOAD SOFTWARE -						*/
/*                                                                          */
/*  Use this software to download instructions to the SLC1657 evaluation 	*/
/*  boards.  It reads an Intel hex formatted program from the disk, formats	*/
/*  it, and downloads it over a PC parallel port cable.						*/
/*																			*/
/*  This software was intended to be used in a DOS environment, including	*/
/*	those supplied under Windows 95, 98 and varients thereof.  However, 	*/
/*  because of security constraints (imposed by Microsoft), it will not 	*/
/*  work with Windows NT.													*/
/*																			*/
/*																			*/
/*                        - SOFTWARE PORTABILITY -                    		*/
/*                                                                          */
/*  This software was originally complied under Turbo C++ 3.0 from Borland	*/
/*  International, Inc.  However, it was written with maximum adherance to	*/
/*  ANSI-C, and should work with most compilers.  							*/
/*																			*/
/*  In order to maximize re-usability, this (and related) software must     */
/*  operate across a wide variety of hardware platforms.  In order to main- */
/*  tain maximum portability among many 'C' compilers, it is recommended    */
/*  that the ANSI-C implementation be used throughout (ANSI/ISO 9899-1990). */
/*  Furthermore, the following variable types should be used whenever       */
/*  possible:                                                               */
/*                                                                          */
/*          Variable Type            Standard Nomenclature & Use            */
/*      ---------------------   ---------------------------------------     */
/*      char                    8-bit, unsigned                             */
/*      signed char             8-bit, signed                               */
/*                                                                          */
/*      unsigned short int      16-bit, unsigned                            */
/*      short int               16-bit, signed                              */
/*                                                                          */
/*      unsigned long int       32-bit, unsigned                            */
/*      long int                32-bit, signed                              */
/*                                                                          */
/*      double                  64-bit, IEEE floating point                 */
/*                                                                          */
/*                                                                          */
/*  Use of other types are discouraged because the ANSI standard does not   */
/*  highly regulate the variable types.  In fact, the standard does not     */
/*  require that any type be contrained to a specific size.  For example,   */
/*  the 'int' type is allowed to be any size as long as the size of         */
/*  char <= int <= long.  Many compilers choose int to be 16 or 32 bits.    */
/*                                                                          */
/*  To overcome this problem, all software and compilers should conform to  */
/*  the above guidelines.  If other types are used, it should be clearly    */
/*  stated in the banner comments where they are used.                      */
/*                                                                          */
/****************************************************************************/

/****************************************************************************/
/* License:         SLC1657 DOWNLOAD Utility                                */
/*                  Copyright (C) 2003 Silicore Corporation                 */
/*                                                                          */
/*                  This library is free software; you can                  */
/*                  redistribute it and/or modify it under the terms        */
/*                  of the GNU Lesser General Public License version        */
/*                  2.1 as published by the Free Software Foundation.       */
/*                                                                          */
/*                  This library is distributed in the hope that it         */
/*                  will be useful, but WITHOUT ANY WARRANTY; without       */
/*                  even the implied warranty of MERCHANTABILITY or         */
/*                  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          */
/*                  Lesser General Public License for more details.         */
/*                                                                          */
/*                  You should have received a copy of the GNU Lesser       */
/*                  General Public License along with this library;         */
/*                  if not, write to the Free Software Foundation,          */
/*                  Inc., 59 Temple Place, Suite 330, Boston, MA            */
/*                  02111-1307  USA                                         */
/*                                                                          */
/* Support:         Support for this software in the form of                */
/*                  maintenance, system integration, consulting and         */
/*                  training is available for a fee from Silicore           */
/*                  Corporation.  For more information please refer         */
/*                  to the Silicore web site at: www.silicore.net.          */
/*                                                                          */
/****************************************************************************/

/****************************************************************************/
/*                                                                          */
/*                           - Module History -                             */
/*                                                                          */
/*            Description                          Name / Date              */
/*  ---------------------------------   ----------------------------------  */
/*  Proj. complete, SLC1655 (VER 1.0):       WD Peterson / 02 APR 1998      */
/*  Upgrade to SLC1657 (VER 1.1):            WD Peterson / 07 MAY 2001      */
/*  Release under the LGPL license:          WD Peterson / 03 SEP 2003      */
/*                                                                          */
/****************************************************************************/

/****************************************************************************/
/*                         - Include File(s) -                        		*/
/****************************************************************************/

#include            <stdio.h>
#include            <string.h>
#include            <stddef.h>
#include			<time.h>


/****************************************************************************/
/*                       - Constant Declaration(s) -                        */
/****************************************************************************/

#define             MAX_STRING                      128
#define             SOFTWARE_VERSION_NUMBER         "1.1"

#define             SET_FP_OFF(p,o) ((*(unsigned *) & p) = o )
#define             SET_FP_SEG(p,s) ((* (((unsigned *) & p) + 1)) = s )
#define             SET_FP(p,s,o)   ( SET_FP_SEG(p,s), SET_FP_OFF(p,o))


/****************************************************************************/
/*                   - Internal Function Declarations -                     */
/****************************************************************************/

void 				delay_100uS( void );
int 				delay_100uS_init( void );
int					download_instruction( int, int );
int                 port_in( int );
void                port_out( int, int );
unsigned short      printer_port_number( int );


/****************************************************************************/
/*                     - Global Variable Definitions -                      */
/****************************************************************************/

unsigned short          control_port;
unsigned short          data_port;
unsigned long			delay_factor;
int						lpt_number;
unsigned short          status_port;


/****************************************************************************/
/*                                                                          */
/*  Function:       main()                                                  */
/*                                                                          */
/*  Description:    This software is used to read an Intel Hex file from	*/
/*					the disk and download it into the emulation ROM in the	*/
/*					SLC1657 processor.  The download takes place over a		*/
/*					Centronics style PC parallel port.					    */
/*																			*/
/*					This software was written for a DOS environment.  It	*/
/*					will work fine from Windows 95/98 environments, but		*/
/*					will not work from Windows NT.  That's because 			*/
/*					Windows NT prohibits all accesses to the parallel port	*/
/*					(evidently for security reasons).						*/
/*                                                                          */
/*					The program uses the printer interface as a general 	*/
/*					purpose eight-bit parallel I/O port.  The bits on the	*/
/*					port are toggled to download instructions to the		*/
/*					SLC1655 processor.										*/
/*																			*/
/*					For more information about the parallel printer port,	*/
/*					please refer to the following references:				*/
/*																			*/
/*					Axelson, Jan.  PARALLEL PORT COMPLETE.  Lakeview		*/
/*					Research 1996.  www.lvr.com  ISBN: 0-9650819-1-5		*/
/*																			*/
/*					Messmer, Hans-Peter.  THE INDISPENSABLE PC HARDWARE		*/
/*					BOOK, THIRD EDITION.  Addison-Wesley 1997.				*/
/*					ISBN: 0-201-40399-4										*/
/*																			*/
/*					IEEE Computer Society.  IEEE STANDARD SIGNALING			*/
/*					METHOD FOR A BIDIRECTIONAL PARALLEL PERIPHERAL 			*/
/*					INTERFACE FOR PERSONAL COMPUTERS.  IEEE STD 1284-1994.	*/
/*					[See Annex 'C'].  IEEE 1994.  ISBN: 1-55937-427-6		*/
/*																			*/
/****************************************************************************/

int main( int argc, char *argv[] )
{
int		address;
int		data;
char	input_string[MAX_STRING];
char	intermediate_filepath[MAX_STRING];
char	intermediate_file_enabled;
FILE   *intermediate_file_pointer;
int		m;
int		n;
int		num_data_records;
char	input_filepath[MAX_STRING];
FILE   *input_file_pointer;
char	temp_string[10];


	/************************************************************************/
	/* Print the header.													*/
	/************************************************************************/

	printf( "\n" );
	printf( "SLC1657 Downloader, VER: %s\n", SOFTWARE_VERSION_NUMBER );


	/************************************************************************/
	/* Assume for now that the intermediate file is turned off.  When used,	*/
	/* the intermediate file contains a list of address and data pairs that	*/
	/* are downloaded over the cable.  It is used as a test utility for		*/
	/* determining if an Intel Hex file is converted correctly.  The		*/
	/* intermediate file has a file extention of '.itr'.					*/
	/************************************************************************/

	intermediate_file_enabled = 'N';


	/************************************************************************/
	/* Set variables indicated by the command line argument(s).             */
	/*																		*/
	/* Command line syntax:	download lpt[n] filepath.hex [-i]				*/
	/*																		*/
	/* where 'n' is the parallel port number (1 <= n <= 4), 'filepath.hex'	*/
	/* is the input hex file (created by the assembler),	and option '-i' */
	/* generates an intermediate output file under 'filepath.itr'.			*/
	/*																		*/
	/* First check the syntax of the command line arguments.				*/
	/************************************************************************/

	if( (argc < 2) || (argc > 4) )
	{
		printf( "\n" );
		printf( "Command line argument syntax error.\n" );
		printf( "Type 'download ?' for correct argument syntax.\n" );
		printf( "Aborting download.\n" );
		return( 0 );
	}

	if( (strcmp( argv[1], "USAGE" ) == 0)
			|| (strcmp( argv[1], "usage" ) == 0)
				|| (strcmp( argv[1], "HELP" ) == 0)
					|| (strcmp( argv[1], "help" ) == 0)
						|| (strcmp( argv[1], "?" ) == 0) )
	{
		printf( "\n" );
		printf( "Command line syntax: download lpt[n] filepath.hex [-i]\n" );
		printf( "\n" );
		printf( "Where:\n" );
		printf( "n:            Parallel port 'LPT' number (1 <= n <= 4)\n" );
		printf( "filepath.hex: Input (Intel Hex) file path\n" );
		printf( "-i:           Generates intermediate file under 'filepath.itr'.\n" );
		return( 0 );
	}


	/************************************************************************/
	/* Reject the port number if it's bad.									*/
	/************************************************************************/

	if( ((*(argv[1]+0) != 'l') && (*(argv[1]+0) != 'L'))
		|| ((*(argv[1]+1) != 'p') && (*(argv[1]+1) != 'P'))
			|| ((*(argv[1]+2) != 't') && (*(argv[1]+2) != 'T')) )
	{
		printf( "Incorrect port argument(s).\n" );
		printf( "Type 'download ?' for correct syntax.\n" );
		printf( "Aborting download.\n" );
		return( 0 );
	}

	sscanf( argv[1]+3, "%d", &lpt_number );

	if( (lpt_number < 1) || (lpt_number > 4) )
	{
		printf( "Incorrect port argument(s).\n" );
		printf( "Type 'download ?' for correct syntax.\n" );
		printf( "Aborting download.\n" );
		return( 0 );
	}


	/************************************************************************/
	/* Read the (input) hex filepath and check that it's an Intel HEX file.	*/
	/************************************************************************/

	strncpy( input_filepath, argv[2], MAX_STRING );

	input_filepath[MAX_STRING - 1] = '\0';

	if( strlen( input_filepath ) == (MAX_STRING - 1) )
	{
		printf( "Input filepath is too long.\n" );
		printf( "Type 'download ?' for correct argument syntax\n" );
		printf( "Aborting download.\n" );
		return( 0 );
	}

	n = strlen( input_filepath ) - 1;
	while( input_filepath[n] != '.' )
	{
		if( n < 1 )
		{
			printf( "Input filepath error.\n" );
			printf( "Type 'download ?' for correct argument syntax\n" );
			printf( "Aborting download.\n" );
			return( 0 );
		}

		--n;
	}

	if( ( (input_filepath[n+1] != 'h') && (input_filepath[n+1] != 'H') )
		|| ( (input_filepath[n+2] != 'e') && (input_filepath[n+2] != 'E') )
			|| ( (input_filepath[n+3] != 'x') && (input_filepath[n+3] != 'X') )
				|| ( input_filepath[n+4] != '\0') )
	{
		printf( "Input filename extension error (not '.hex').\n" );
		printf( "Type 'download ?' for correct argument syntax\n" );
		printf( "Aborting download.\n" );
		return( 0 );
	}


	/************************************************************************/
	/* Determine if the intermediate file should be created.  If so, then	*/
	/* create the filepath specifier for the file.							*/
	/************************************************************************/

	if( argc == 4 )
	{
		if( (*(argv[3]+0) != '-')
			|| ((*(argv[3]+1) != 'i') && (*(argv[3]+1) != 'I')) )
		{
			printf( "Incorrect option argument(s).\n" );
			printf( "Type 'download ?' for correct syntax.\n" );
			printf( "Aborting download.\n" );
			return( 0 );
		}

		strncpy( intermediate_filepath, input_filepath, MAX_STRING );

		n = strlen( intermediate_filepath ) - 1;
		while( intermediate_filepath[n] != '.' ) { --n; };

		intermediate_filepath[n+1] = 'i';
		intermediate_filepath[n+2] = 't';
		intermediate_filepath[n+3] = 'r';

		intermediate_file_enabled = 'Y';
	}


	/************************************************************************/
	/* Initialize the time delay generator.									*/
	/************************************************************************/

	delay_100uS_init();


	/************************************************************************/
	/* Initialize the parallel port.  First set up the printer port 		*/
	/* addresses.  															*/
	/************************************************************************/

	data_port = printer_port_number( lpt_number );
	status_port = data_port + 1;
	control_port = data_port + 2;


	/************************************************************************/
	/*  Verify that the printer port number is valid for an IBM-PC or		*/
	/* compatible.  If it is, then continue.  If it isn't, then complain	*/
	/* to the user and quit.												*/
	/************************************************************************/

	if( (data_port != 0x3bc) && (data_port != 0x378)
							&& (data_port != 0x278) && (data_port != 0x2bc) )
	{
		printf( "Parallel port initialization failure. Verify that port exists.\n" );
		printf( "Aborting download.\n" );
		return( 0 );
	}


	/************************************************************************/
	/* Initialize the control port.                                         */
	/************************************************************************/

	port_out( control_port, 0x00 );


	/************************************************************************/
	/* Set the data port to 0xfb.  This asserts the 'PROG*' signal, and		*/
	/* resets the microcontroller.											*/
	/************************************************************************/

	port_out( data_port, 0xfb );


	/************************************************************************/
	/*  Flush all I/O buffers.                                              */
	/************************************************************************/

	fflush( NULL );


	/************************************************************************/
	/* Open the input file.													*/
	/************************************************************************/

	if( (input_file_pointer = fopen( input_filepath, "r" )) == NULL )
	{
		printf( "\n" );
		printf( "ERROR: Couldn't open %s\n", input_filepath );
		printf( "Aborting download.\n" );
		fclose( input_file_pointer );
		return( 0 );
	}

	rewind( input_file_pointer );


	/************************************************************************/
	/* Open the intermediate file (if enabled).                             */
	/************************************************************************/

	if( intermediate_file_enabled == 'Y' )
	{
		if( (intermediate_file_pointer = fopen( intermediate_filepath, "w" )) == NULL )
		{
			printf( "\n" );
			printf( "ERROR: Couldn't open %s\n", input_filepath );
			printf( "Aborting download.\n" );
			fclose( input_file_pointer );
			fclose( intermediate_file_pointer );
			return( 0 );
		}

		rewind( intermediate_file_pointer );
	}


	/************************************************************************/
	/* Read the data, convert it, download it and save it to the intermedi-	*/
	/* ate file (if enabled).												*/
	/************************************************************************/

	while( fscanf( input_file_pointer, "%s", &input_string ) != EOF )
	{
		n = 0;

		/********************************************************************/
		/* Verify that the first symbol is a ':'.							*/
		/********************************************************************/

		if( input_string[n++] != ':' )
		{
			printf( "\n" );
			printf( "ERROR: Unusual file format character found in input file: %s\n", input_filepath );
			printf( "Expected ':', but read '%c'.\n", input_string[n-1] );
			printf( "Aborting download.\n" );
			fclose( input_file_pointer );
			fclose( intermediate_file_pointer );
			return( 0 );
		}


		/********************************************************************/
		/* Obtain the number of data records on the current line.			*/
		/********************************************************************/

		temp_string[0] = input_string[n++];
		temp_string[1] = input_string[n++];
		temp_string[2] = '\0';

		sscanf( temp_string, "%X", &num_data_records );


		/********************************************************************/
		/* Read the starting address of the line.							*/
		/********************************************************************/

		temp_string[0] = input_string[n++];
		temp_string[1] = input_string[n++];
		temp_string[2] = input_string[n++];
		temp_string[3] = input_string[n++];
		temp_string[4] = '\0';

		sscanf( temp_string, "%X", &address );


		/********************************************************************/
		/* Divide the byte address by two to get the instruction address.	*/
		/********************************************************************/

		address = address / 2;


		/********************************************************************/
		/* Ignore the next two characters in the line.						*/
		/********************************************************************/

		n = n + 2;


		/********************************************************************/
		/* Scan in the data from the line.									*/
		/********************************************************************/

		while( num_data_records > 0 )
		{
			/****************************************************************/
			/* Read the next instruction.									*/
			/****************************************************************/

			temp_string[0] = input_string[n+2];
			temp_string[1] = input_string[n+3];
			temp_string[2] = input_string[n+0];
			temp_string[3] = input_string[n+1];
			temp_string[4] = '\0';

			n = n + 4;

			sscanf( temp_string, "%X", &data );


			/****************************************************************/
			/* Verify that the instruction address is legitimate.  This has */
			/* the effect of stripping out the special configuration bits 	*/
			/* can be used with the Microchip implementation of the PIC		*/
			/* processor.													*/
			/****************************************************************/

			if( (address >= 0) && (address <= 0x07FF) )
			{
				/************************************************************/
				/* Print out the current address and instruction word. 		*/
				/************************************************************/

				printf ( "\r" );
				printf ( "ADDR: 0x%03X, INST: 0x%03X", address, data );


				/************************************************************/
				/* Send the address and data value of the instruction to 	*/
				/* the microcontroller.										*/
				/************************************************************/

				download_instruction( address, data );


				/************************************************************/
				/* If the intermediate file function is enabled, then send	*/
				/* the data to the output file.								*/
				/************************************************************/

				if( intermediate_file_enabled == 'Y' )
				{
					fprintf( intermediate_file_pointer, "%03X\t%03X\n", address, data );
				}
			}

			num_data_records = num_data_records - 2;
			address++;
		}
	}

	/************************************************************************/
	/* Set the data port to 0xff.  This negates the 'PROG*' signal, and		*/
	/* starts the microcontroller.											*/
	/************************************************************************/

	port_out( data_port, 0xff );


	/************************************************************************/
	/*	Download complete.  Cleanup and exit.  								*/
	/************************************************************************/

	fclose( input_file_pointer );

	if( intermediate_file_enabled == 'Y' )
	{
		fclose( intermediate_file_pointer );
	}

	printf( "\r" );
	printf( "Download complete.              \n" );

	return( 0 );
}


/****************************************************************************/
/*                                                                          */
/*  Funtion:        delay_100uS()                                           */
/*                                                                          */
/*  Description:    Generates a time delay of approximetely 100 uS.  Before	*/
/*					calling this function, the 'delay_100uS_init() routine	*/
/*					should be called to set up the delay factors for this	*/
/*					particular computer.     								*/
/*																			*/
/*					The 'delay_100uS()' function is used because there are	*/
/*					no portable fine granularity (< 1 millisecond) delay 	*/
/*					routines for IBM-PC compatible operating systems.		*/
/*                                                                          */
/****************************************************************************/

void delay_100uS( void )
{
unsigned long	loop_count;

	for( loop_count = 0; loop_count <= delay_factor; loop_count++ )
	{
	}
}


/****************************************************************************/
/*                                                                          */
/*  Funtion:        delay_100uS_init()                                      */
/*                                                                          */
/*  Description:    Initializes the variable 'delay_factor' for use with 	*/
/*					the 'delay_100uS()' function.							*/
/*                                                                          */
/****************************************************************************/

int delay_100uS_init( void )
{
double			start_time;
unsigned long 	new_delay_factor;


	/************************************************************************/
	/* Initialize the 'delay_factor' variable to zero.  This causes the 	*/
	/* the 'delay_100uS()' function to perform one iteration, and then		*/
	/* return when initializing the time delay.								*/
	/************************************************************************/

	delay_factor = 0;


	/************************************************************************/
	/* Wait for the clock() value to tick over.  This eliminates the error	*/
	/* caused by time 'rounding'.											*/
	/************************************************************************/

	start_time = (double) ( clock() / CLOCKS_PER_SEC );

	while( start_time == (double) ( clock() / CLOCKS_PER_SEC ) )
	{}


	/************************************************************************/
	/* Determine the number of times 'delay_100uS' is called in 0.5 sec.	*/
	/************************************************************************/

	start_time = (double) ( clock() / CLOCKS_PER_SEC );

	new_delay_factor = 0;

	do
	{
		delay_100uS();
		new_delay_factor++;
	}
	while( (( clock() / CLOCKS_PER_SEC ) - start_time ) < 0.5 );



	/************************************************************************/
	/* Update the delay factor variable for 100 uS operation.				*/
	/************************************************************************/

	delay_factor = (unsigned long) ( new_delay_factor / 200 );

	return( 0 );
}


/****************************************************************************/
/*                                                                          */
/*  Funtion:        download_instruction()                                  */
/*                                                                          */
/*  Description:    Downloads an instruction address/data pair through the	*/
/*					parallel port.											*/
/*																			*/
/****************************************************************************/

int	download_instruction( int address, int data )
{
int				n;
unsigned long	output_bits;

	/************************************************************************/
	/* Create a string of output bits.   									*/
	/************************************************************************/

	output_bits = (unsigned long) data;
	output_bits = output_bits << 11;
	output_bits = output_bits | (unsigned long) address;


	/************************************************************************/
	/* Shift the bits out with the clock signal.							*/
	/************************************************************************/

	for( n = 0; n < 23; n++ )
	{
		/********************************************************************/
		/* Next data bit is a zero.											*/
		/********************************************************************/

		if( ( output_bits & 0x00400000 ) == 0x00000000 )
		{
			port_out( data_port, 0xfb );		/* Data bit.				*/
			delay_100uS();
			port_out( data_port, 0xfa );		/* Clock bit.				*/
			delay_100uS();
		}

		/********************************************************************/
		/* Next data bit is a one.											*/
		/********************************************************************/

		else
		{
			port_out( data_port, 0xf9 );		/* Data bit.				*/
			delay_100uS();
			port_out( data_port, 0xf8 );		/* Clock bit.				*/
			delay_100uS();
		}


		/********************************************************************/
		/* Shift output bits over one.										*/
		/********************************************************************/

		output_bits = output_bits << 1;

	}


	/************************************************************************/
	/* Assert and negate 'PLCH*'.  This latches the data into the emulation	*/
	/* ROM memory.															*/
	/************************************************************************/

	port_out( data_port, 0xf3 );
	delay_100uS();
	port_out( data_port, 0xfb );
	delay_100uS();

	return( 0 );
}


/****************************************************************************/
/*                                                                          */
/*  Funtion:        port_in()                                               */
/*                                                                          */
/*  Description:    Reads the 80X86 I/O space register and returns the      */
/*                  value.  Uses non-ANSI function 'inport()', which is     */
/*                  port of the Borland Tubo 'C' toolbox.                   */
/*                                                                          */
/****************************************************************************/

int port_in( port_number )
{
	return( inport(port_number) );
}


/****************************************************************************/
/*                                                                          */
/*  Funtion:        port_out()                                              */
/*                                                                          */
/*  Description:    Writes to the 80X86 I/O space register and returns the  */
/*                  value.  Uses non-ANSI function 'outport()', which is    */
/*                  port of the Borland Tubo 'C' toolbox.                   */
/*                                                                          */
/****************************************************************************/

void port_out( port_number, port_data )
{
	outport( port_number, port_data );
}


/****************************************************************************/
/*                                                                          */
/*  Funtion:        printer_port_number()                                   */
/*                                                                          */
/*  Description:    Returns the printer I/O port address for IBM-PC         */
/*                  compatible systems.  Function is passed the port number */
/*                  '1' == LPT1, '2' == LPT2, etc.                          */
/*                                                                          */
/*                  This code is intended for use with IBM-PC (MS-DOS)      */
/*                  BIOS.  Converts 80X86 segmented address (40:08) into    */
/*                  a linear address, and reads in the value of the I/O     */
/*                  port address.  Address conversion uses macros (defined  */
/*                  above).                                                 */
/*                                                                          */
/****************************************************************************/

unsigned short printer_port_number( int LPTX_port_number )
{
unsigned short far *printer_port_pointer;

	if( LPTX_port_number == 1 )
	{
		SET_FP_OFF( printer_port_pointer, 0x08 );
		SET_FP_SEG( printer_port_pointer, 0x40 );
		SET_FP( printer_port_pointer, 0x40, 0x08 );
	}

	if( LPTX_port_number == 2 )
	{
		SET_FP_OFF( printer_port_pointer, 0x0a );
		SET_FP_SEG( printer_port_pointer, 0x40 );
		SET_FP( printer_port_pointer, 0x40, 0x0a );
	}

	if( LPTX_port_number == 3 )
	{
		SET_FP_OFF( printer_port_pointer, 0x0c );
		SET_FP_SEG( printer_port_pointer, 0x40 );
		SET_FP( printer_port_pointer, 0x40, 0x0c );
	}

	if( LPTX_port_number == 4 )
	{
		SET_FP_OFF( printer_port_pointer, 0x0e );
		SET_FP_SEG( printer_port_pointer, 0x40 );
		SET_FP( printer_port_pointer, 0x40, 0x0e );
	}

	return( *printer_port_pointer );

}
