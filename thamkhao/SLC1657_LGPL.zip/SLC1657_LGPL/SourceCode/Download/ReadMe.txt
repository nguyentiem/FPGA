Note: The 'DOWNLOAD.EXE' executable file was prepared for operation under MS DOS only.


