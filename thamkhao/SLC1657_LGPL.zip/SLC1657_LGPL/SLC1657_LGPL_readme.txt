Notes for the SLC1657 Microcontroller / LGPL Distribution
---------------------------------------------------------


Release 2.0 Notes (3 Sep 2003)
------------------------------

Release 2.0 was the first version of the SLC1657 microcontroller released under the LGPL license.  All VHDL, 'C' and assembler source files were changed to include the new license.

You may find that some source code files in the application examples have an older, proprietary license.  These were left 'as-is' in the distribution to avoid the possibility of introducing any errors into the examples.  However, if you look under the 'VHDL_Sources' directory you will find the modified files under the LGPL license.  Fixing this will be left to a future version.

WD Peterson - 3 Sep 2003



Documentation
-------------

All documentation for the SLC1657 LGPL distribution is made available under the GNU Free Documentation License, Version 1.2.  A copy of the license is available in the 'Licenses' directory.  

All original documentation files may not be present in the distribution that you received.  For example, distributions from the Silicore Website are too large to include original word processing and drawing files.  These are available from Silicore Corporation on a CD ROM.  To obtain copies of the complete distribution, please contact:

Silicore Corporation
6310 Butterworth Lane
Corcoran, MN  USA  55340
URL: www.silicore.net
EML: wadep@silicore.net
TEL: (763) 478-3567
FAX: (763) 478-3568

Please be advised that Silicore may charge a distribution fee for this service.  Contact Silicore Corporation for details.  Original documentation files are created with the following application programs:


  File Type      File Extension       Created with
--------------  ----------------  ---------------------
Word processor        .doc         Microsoft Word 2002
Illustrations         .skf         Autosketch Ver 8.0
Portable docs         .pdf         Adobe Acrobat 5.01


